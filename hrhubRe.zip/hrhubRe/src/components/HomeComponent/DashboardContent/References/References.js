import React from 'react'

export default function References() {
  return (
    <div>References</div>
  )
}

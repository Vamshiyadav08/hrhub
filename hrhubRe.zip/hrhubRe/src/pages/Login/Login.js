import React from 'react';
import LoginComponent from '../../components/LoginComponent/LoginComponent';

export default function Login() {
  return (
    <div>
        <LoginComponent/>
    </div>
  )
}
